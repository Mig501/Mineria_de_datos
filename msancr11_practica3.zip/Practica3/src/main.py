from controller.controller import ValidationController

if __name__ == "__main__":
    controller = ValidationController()
    controller.run()
